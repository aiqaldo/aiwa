const opening=document.getElementById('opening');
const envelopeButton=document.getElementById('envelopeButton');
const flowerScreen=document.getElementById('flowerScreen');
const letterButton=document.getElementById('letterButton');
const letterScreen=document.getElementById('letterScreen');
const resetBtn=document.getElementById('resetBtn');
const audio=document.getElementById('audio');
const audioFile=document.getElementById('audioFile');
const songPlay=document.getElementById('songPlay');
const songLabel=document.getElementById('songLabel');

let audioUrl=null;
const DB='nogoro-angin-persistent';
const STORE='music';

function dbOpen(){
  return new Promise((resolve,reject)=>{
    const r=indexedDB.open(DB,1);
    r.onupgradeneeded=()=>r.result.createObjectStore(STORE);
    r.onsuccess=()=>resolve(r.result);
    r.onerror=()=>reject(r.error);
  });
}
async function saveSong(file){
  const db=await dbOpen();
  await new Promise((resolve,reject)=>{
    const tx=db.transaction(STORE,'readwrite');
    tx.objectStore(STORE).put({blob:file,name:file.name},'song');
    tx.oncomplete=resolve; tx.onerror=()=>reject(tx.error);
  });
}
async function loadSong(){
  try{
    const db=await dbOpen();
    const rec=await new Promise((resolve,reject)=>{
      const q=db.transaction(STORE,'readonly').objectStore(STORE).get('song');
      q.onsuccess=()=>resolve(q.result); q.onerror=()=>reject(q.error);
    });
    if(rec?.blob){
      audioUrl=URL.createObjectURL(rec.blob);
      audio.src=audioUrl;
      songLabel.textContent=rec.name||'Nogoro Angin';
    }
  }catch(e){console.warn('Audio persistence unavailable',e)}
}
function openEnvelope(){
  opening.classList.add('hide');
  flowerScreen.classList.add('show');
  flowerScreen.setAttribute('aria-hidden','false');
}
function openLetter(){
  letterScreen.classList.add('show');
  letterScreen.setAttribute('aria-hidden','false');
}
function reset(){
  audio.pause();
  audio.currentTime=0;
  songPlay.textContent='▶';
  letterScreen.classList.remove('show');
  flowerScreen.classList.remove('show');
  flowerScreen.setAttribute('aria-hidden','true');
  opening.classList.remove('hide');
}
envelopeButton.onclick=openEnvelope;
letterButton.onclick=openLetter;
songPlay.onclick=()=>{
  if(!audio.src){audioFile.click();return}
  if(audio.paused) audio.play().catch(()=>{});
  else audio.pause();
};
audioFile.onchange=async e=>{
  const file=e.target.files?.[0];
  if(!file)return;
  try{await saveSong(file)}catch(err){console.warn(err)}
  if(audioUrl)URL.revokeObjectURL(audioUrl);
  audioUrl=URL.createObjectURL(file);
  audio.src=audioUrl;
  songLabel.textContent=file.name;
  audio.play().catch(()=>{});
};
audio.onplay=()=>songPlay.textContent='Ⅱ';
audio.onpause=()=>songPlay.textContent='▶';
audio.onended=()=>songPlay.textContent='▶';
resetBtn.onclick=reset;
loadSong();
