# Nogoro Angin Interactive v3

Flow: Sampul -> bunga keluar -> open the letter -> surat/music.

- Tiada button Play/timeline panjang di bawah.
- Tiada logo TikTok.
- Bunga dibuat terus dengan SVG/CSS supaya sentiasa nampak.
- Lagu yang dipilih disimpan dalam IndexedDB browser dan tidak dibuang bila reset.
